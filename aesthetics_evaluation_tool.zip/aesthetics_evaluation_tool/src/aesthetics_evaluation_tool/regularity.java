package aesthetics_evaluation_tool;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class regularity {
	public static int occY=0;
	public static int occX=0;
	public static double value=0;
	public static  int distanceX=0;
	public static  int distanceY=0;
	public static  int distance=0;
	
	public int getdistance(){
	    return distance;
	}
	public int getdistanceX(){
	    return distanceX;
	}
	public int getdistanceY(){
	    return distanceY;
	}
	public double regularity() throws IOException {
		// TODO Auto-generated constructor stub
		
		
		
		int indice_X=0;
		int indice_Y=0;
				//main_launcher ML= new main_launcher();
		    	String file=main_launcher.data_File;
		    	
		    	InputStream input = new FileInputStream(file);
				 HSSFWorkbook wb     = new HSSFWorkbook(input);
				 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
				 //row number
				 int rowTotal = sheet.getLastRowNum();
			
		      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
		          rowTotal++;
		      }
		    	
		      for ( int r=0;r<1; r++){     
					 HSSFRow row     = sheet.getRow(r); 
					 
					 //get cell number in each row
					 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
					 
					 // parse cells values of each row
					 for (int c=0;c<noOfColumns; c++)
			    	        
				        {
						 
					 HSSFCell cell= row.getCell(c);
					// System.out.println("row="+r+"###"+cell.getStringCellValue() );
					 
					 String text= cell.getStringCellValue();
					 //System.out.println("text="+text);
					 if (text.equals("x"))
					 {
						indice_X=c; 
						//System.out.println(indice_width);
					 }
					 
					 if (text.equals("y"))
					 {
						indice_Y=c; 
						//System.out.println(indice_height);
					 } 
				        }
					 }
		      
		      int [] Xtab=new int[rowTotal]; 
			  int [] Ytab=new int[rowTotal]; 
				
			  int [] Xtab_original=new int[rowTotal]; 
			  int [] Ytab_original=new int[rowTotal];
			 
			  
		      for ( int r=1;r<rowTotal; r++)
		      
		      {   
		    	  HSSFRow row     = sheet.getRow(r); 
		    	  
		    	  //fill the X table
		    	  for (int c=indice_X;c<indice_X+1; c++)
		  	        
			        {
		    		  HSSFCell cell= row.getCell(c);
		    		  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
		    		  Xtab[r-1]= (int)(cell.getNumericCellValue());
		    		  Xtab_original[r-1]=(int)(cell.getNumericCellValue());
			        }
		    	  
		    	  
		    	//fill the Y table
		    	  
		    	  for (int c=indice_Y;c<indice_Y+1; c++)
		    	        
			        {
		  		  HSSFCell cell= row.getCell(c);
		  		  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
		  		  Ytab[r-1]= (int)(cell.getNumericCellValue());
		  		Ytab_original[r-1]=(int)(cell.getNumericCellValue());
			        }
		      }
		      
		      //afficher xtab et ytab
		      for (int k = 0; k < Xtab.length-1; ++k) { 
		  			////System.out.println("vals dans xtab=="+Xtab[k]);
		  			
		  		}
		      ////System.out.println("***********************");
		      for (int k = 0; k < Ytab.length-1; ++k) { 
		  			////System.out.println("vals dans ytab=="+Ytab[k]);
		  			
		  		}
		      ////System.out.println("***********************");
// look for occurrences of X


		for (int i = 0; i < Xtab.length-1; ++i) { 
			int val =Xtab[i];
			int indice=i;
			//System.out.println("val"+i+"=="+val);	
			
			for (int j = i+1; j < Xtab.length-1; ++j) 
			{
				if(val==Xtab[j])
				{
					
					Xtab[j]=0;
				}
				
				 if(val==0) {
				        i = indice;
				    } 
				
				
			}


			}
		
		
		
		
		
		for (int k = 0; k < Xtab.length-1; ++k) { 
			////System.out.println("outputsizes in X=="+Xtab[k]);
			
		}
		
	
		for (int l = 0; l < Xtab.length-1; ++l) { 
			
			if(Xtab[l]!=0)
			{
				occX++;
			}
			
		}
		
		
		//System.out.println("occurrence X= "+occX);
		////System.out.println("***********************");
		// look for occurrences of Y
		

				for (int i = 0; i < Ytab.length-1; ++i) { 
					int val =Ytab[i];
					int indice=i;
					//System.out.println("val"+i+"=="+val);	
					
					for (int j = i+1; j < Ytab.length-1; ++j) 
					{
						if(val==Ytab[j])
						{
							
							Ytab[j]=0;
						}
						
						 if(val==0) {
						        i = indice;
						    } 
						
						
					}


					}
				
				
				
				
				
				for (int k = 0; k < Ytab.length-1; ++k) { 
					////System.out.println("outputsizes in Y=="+Ytab[k]);
					
				}
				
				for (int l = 0; l < Ytab.length-1; ++l) { 
					
					if(Ytab[l]!=0)
					{
						occY++;
					}
					
				}
				//System.out.println("occurrence Y= "+occY);
				////System.out.println("***********************");
				
				
		//look for different spaces between the widgets		
				 int X_length=(Xtab_original.length*(Xtab_original.length-1))/2;
					int Y_length=(Ytab_original.length*(Ytab_original.length-1))/2;
						int [] X_distance_diff=new int[X_length]; 
						int [] Y_distance_diff=new int[Y_length]; 
				
			String val_substractionX="";
		
				for (int k = 0; k < Xtab_original.length-1; ++k) { 
						
					int val= Xtab_original[k];
					//System.out.println("val de k= "+k+"egale= "+val);
					for (int j = k+1; j < Xtab_original.length-1; ++j)
					{
						int val1=Xtab_original[j];
						//System.out.println("val1= "+val1);
						int val_sub=Math.abs((int)(val-val1));
						//System.out.println("val substraction= "+val_sub);
						 X_distance_diff[k]=(int)val_sub;
							//System.out.println("differences in X=="+X_distance_diff[k]);
							val_substractionX=val_substractionX+val_sub+",";
					}
					
					
					
					
				}
				////System.out.println("*****************");
				//System.out.println("val_substractionX= "+val_substractionX);
				
				
				String[] integerStringsX = val_substractionX.split(","); 
		    	 
				 
				// Creates the integer array.
				for (int i = 0; i <  integerStringsX.length; i++){
					 X_distance_diff[i] = Integer.parseInt(integerStringsX[i]); 
				//Parses the integer for each string.
				}
		    	   
				for (int k = 0; k < X_distance_diff.length; ++k) { 
					////System.out.println("differences in X=="+X_distance_diff[k]);	
				}
				////System.out.println("*****************");
				
				//****************************** y
				
				String val_substractionY="";
				
				for (int k = 0; k < Ytab_original.length-1; ++k) { 
						
					int val= Ytab_original[k];
					//System.out.println("val de k= "+k+"egale= "+val);
					for (int j = k+1; j < Ytab_original.length-1; ++j)
					{
						int val1=Ytab_original[j];
						//System.out.println("val1= "+val1);
						int val_sub=Math.abs((int)(val-val1));
						//System.out.println("val substraction= "+val_sub);
						 Y_distance_diff[k]=(int)val_sub;
							//System.out.println("differences in Y=="+Y_distance_diff[k]);
							val_substractionY=val_substractionY+val_sub+",";
					}
					
					
					
					
				}
				
				//System.out.println("val_substractionY= "+val_substractionY);
				
				
				String[] integerStringsY = val_substractionY.split(","); 
		    	 
				 
				// Creates the integer array.
				for (int i = 0; i <  integerStringsY.length; i++){
					 Y_distance_diff[i] = Integer.parseInt(integerStringsY[i]); 
				//Parses the integer for each string.
				}
		    	   
				for (int k = 0; k < Y_distance_diff.length; ++k) { 
					////System.out.println("differences in Y=="+Y_distance_diff[k]);	
				}
				
				////System.out.println("*****************");
				//search for diferent X  in differences tables
				
				
				
				for (int i = 0; i < X_distance_diff.length-1; ++i) { 
					int val =X_distance_diff[i];
					int indice=i;
					//System.out.println("val"+i+"=="+val);	
					
					for (int j = i+1; j < X_distance_diff.length-1; ++j) 
					{
						if(val==0) {
					        i = indice;
					        
					    } 
						
						else if(val==X_distance_diff[j])
						{
							
							X_distance_diff[j]=0;
						}
						
						 
						
						
					}


					}
				
				for (int k = 0; k < X_distance_diff.length-1; ++k) { 
				////System.out.println("distanct differences in X=="+X_distance_diff[k]);	
			}

				for (int l = 0; l < X_distance_diff.length-1; ++l) { 
					
					if(X_distance_diff[l]!=0)
					{
						distanceX++;
					}
					
				}
				////System.out.println(" distanct X=="+distanceX);
				////System.out.println("*****************");
				//search for diferent Y  in differences tables
				
				
				for (int i = 0; i < Y_distance_diff.length-1; ++i) { 
					int val =Y_distance_diff[i];
					int indice=i;
					//System.out.println("val"+i+"=="+val);	
					
					for (int j = i+1; j < Y_distance_diff.length; ++j) 
					{
						if(val==Y_distance_diff[j])
						{
							
							Y_distance_diff[j]=0;
						}
						
						 if(val==0) {
						        i = indice;
						    } 
						
						
					}


					}
				
			
				for (int k = 0; k < Y_distance_diff.length-1; ++k) { 
					////System.out.println("distanct differences in Y=="+Y_distance_diff[k]);	
				}
				for (int l = 0; l < Y_distance_diff.length; ++l) { 
					
					if(Y_distance_diff[l]!=0)
					{
						distanceY++;
					}
					
				}
				
				////System.out.println(" distanct Y=="+distanceY);
			 distance=distanceX+distanceY;	
				
				
				
			//System.out.println("you have "+distance+" different spaces between your widgets."+"\n" +distanceX+" differences in rows, and "+distanceY+" different distances in columns");
				
				
	double Reg= Math.abs(1- ((((double)(occX)+ (double) (occY)+ (double) (distance) )/ (3*(rowTotal-1) )))/100);	
				//double Reg= Math.abs(1- (((double)(occX)+ (double) (occY)+5/ (3*(double)(rowTotal) ))));
	 value =Double.parseDouble(new DecimalFormat("##.###").format(Reg));	
	 if (Math.abs(value)>=1)
	 {
		 value=1;
	 }
	return Math.abs(value);
		
		
		
		
		
		
		
		
	}

}
