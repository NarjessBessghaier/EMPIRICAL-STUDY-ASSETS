package aesthetics_evaluation_tool;

import java.text.DecimalFormat;


public class nb_elements {
	public static double value=0;
	public double nb_elements() {
		
		// TODO Auto-generated constructor stub
		
		double value = economy.taille;
		
		 value= (1-0)* ((value-7)/(double)(45-7))+0;

		 value =Double.parseDouble(new DecimalFormat("##.###").format(value));
		 //System.out.println(value);
		 if (value>=1)
		 {
			 value=1;
		 }
		return value;
		
	}

}
